  #action 1 :-
  create database Aircargo;
  use aircargo;
  #action 2 - ER diagram
  #action 3 :-
  select *
  from passengers_on_flights
  where route_id between 1 and 25;
  select * from  ticket_details;
  #action 4:-
  SELECT COUNT(class_id) Business_Class, SUM(price_per_ticket) revenue_in_Business 
		FROM ticket_details 
		WHERE class_id = 'Business';
  #action 5 :-
        SELECT CONCAT(first_name,' ',last_name) FULL_NAME FROM customer;
  #action 6:-
	SELECT customer.customer_id,customer.first_name,customer.last_name,ticket_details.p_date
		FROM customer   
		INNER JOIN ticket_details
		ON customer.customer_id = ticket_details.customer_id;
  #action 7:-
       	SELECT first_name, last_name 
		FROM customer
		WHERE customer_id IN (SELECT customer_id 
							  FROM ticket_details 
							  WHERE brand = 'Emirates'); 
   #action 8:-
		SELECT * 
        FROM customer
		WHERE customer_id IN (
								SELECT customer_id
								FROM passengers_on_flights
								WHERE class_id = 'Economy Plus') 
		ORDER BY customer_id;
  #action 9:-
       SELECT 
		IF(SUM(Price_per_ticket)>10000,'Revenue is greater than 10000','Revenue is less than 10000')  as Check_if_revenue_greater_than_10000 
		from ticket_details;
 #action 10 :-
       CREATE USER junior@localhost 
		IDENTIFIED BY 'junior123';
		GRANT EXECUTE ON securitydb.* 
		TO junior@localhost;
#action 11:-
       		SELECT *,
		   MAX(Price_per_ticket) OVER (PARTITION BY class_id) as max_price 
		FROM ticket_details;
 #action 12:-
        CREATE INDEX idx_route_id ON passengers_on_flights (route_id);
        	
            SELECT customer_id, depart, arrival, aircraft_id 
		FROM passengers_on_flights 
		WHERE route_id = '4';
# action 13 :-
      SELECT * 
		FROM passengers_on_flights 
		WHERE route_id = '04';
#action 14 :-
      SELECT customer_id, aircraft_id, SUM(Price_per_ticket) as Total_Price 
		FROM ticket_details 
		GROUP BY customer_id, aircraft_id WITH ROLLUP;
 # action 15:-
     CREATE VIEW BusinessClassView AS 
		SELECT customer_id, class_id, brand 
		from ticket_details 
		where class_id = "Business";
        
        select * from BusinessClassView;
#action 16:-
      DELIMITER &&
		CREATE PROCEDURE Get_Customers_With_2K()
		BEGIN
		      SELECT * 
              FROM routes 
              where distance_miles>2000;
		END &&
		DELIMITER ;
        
		CALL Get_Customers_With_2K();
#action 17:-        
     SELECT customer_id, SUM(no_of_tickets) AS total_tickets, SUM(Price_per_ticket * no_of_tickets) AS total_price
		FROM ticket_details
		GROUP BY customer_id;   
        
        
        